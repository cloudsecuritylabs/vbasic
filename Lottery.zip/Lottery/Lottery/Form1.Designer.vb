﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNum1 = New System.Windows.Forms.Label()
        Me.lblNum2 = New System.Windows.Forms.Label()
        Me.lblNum3 = New System.Windows.Forms.Label()
        Me.lblNum4 = New System.Windows.Forms.Label()
        Me.lblNum5 = New System.Windows.Forms.Label()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblUserNum5 = New System.Windows.Forms.Label()
        Me.lblUserNum4 = New System.Windows.Forms.Label()
        Me.lblUserNum3 = New System.Windows.Forms.Label()
        Me.lblUserNum2 = New System.Windows.Forms.Label()
        Me.lblUserNum1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblNum1
        '
        Me.lblNum1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum1.Location = New System.Drawing.Point(132, 20)
        Me.lblNum1.Name = "lblNum1"
        Me.lblNum1.Size = New System.Drawing.Size(58, 23)
        Me.lblNum1.TabIndex = 0
        Me.lblNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum2
        '
        Me.lblNum2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum2.Location = New System.Drawing.Point(213, 20)
        Me.lblNum2.Name = "lblNum2"
        Me.lblNum2.Size = New System.Drawing.Size(58, 23)
        Me.lblNum2.TabIndex = 1
        Me.lblNum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum3
        '
        Me.lblNum3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum3.Location = New System.Drawing.Point(295, 20)
        Me.lblNum3.Name = "lblNum3"
        Me.lblNum3.Size = New System.Drawing.Size(58, 23)
        Me.lblNum3.TabIndex = 2
        Me.lblNum3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum4
        '
        Me.lblNum4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum4.Location = New System.Drawing.Point(378, 20)
        Me.lblNum4.Name = "lblNum4"
        Me.lblNum4.Size = New System.Drawing.Size(58, 23)
        Me.lblNum4.TabIndex = 3
        Me.lblNum4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum5
        '
        Me.lblNum5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNum5.Location = New System.Drawing.Point(462, 20)
        Me.lblNum5.Name = "lblNum5"
        Me.lblNum5.Size = New System.Drawing.Size(58, 23)
        Me.lblNum5.TabIndex = 4
        Me.lblNum5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnGenerate
        '
        Me.btnGenerate.Location = New System.Drawing.Point(213, 72)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(75, 23)
        Me.btnGenerate.TabIndex = 5
        Me.btnGenerate.Text = "Generate Numbers"
        Me.btnGenerate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(335, 72)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblUserNum5
        '
        Me.lblUserNum5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserNum5.Location = New System.Drawing.Point(462, 121)
        Me.lblUserNum5.Name = "lblUserNum5"
        Me.lblUserNum5.Size = New System.Drawing.Size(58, 23)
        Me.lblUserNum5.TabIndex = 11
        Me.lblUserNum5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUserNum4
        '
        Me.lblUserNum4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserNum4.Location = New System.Drawing.Point(378, 121)
        Me.lblUserNum4.Name = "lblUserNum4"
        Me.lblUserNum4.Size = New System.Drawing.Size(58, 23)
        Me.lblUserNum4.TabIndex = 10
        Me.lblUserNum4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUserNum3
        '
        Me.lblUserNum3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserNum3.Location = New System.Drawing.Point(295, 121)
        Me.lblUserNum3.Name = "lblUserNum3"
        Me.lblUserNum3.Size = New System.Drawing.Size(58, 23)
        Me.lblUserNum3.TabIndex = 9
        Me.lblUserNum3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUserNum2
        '
        Me.lblUserNum2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserNum2.Location = New System.Drawing.Point(213, 121)
        Me.lblUserNum2.Name = "lblUserNum2"
        Me.lblUserNum2.Size = New System.Drawing.Size(58, 23)
        Me.lblUserNum2.TabIndex = 8
        Me.lblUserNum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUserNum1
        '
        Me.lblUserNum1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserNum1.Location = New System.Drawing.Point(132, 121)
        Me.lblUserNum1.Name = "lblUserNum1"
        Me.lblUserNum1.Size = New System.Drawing.Size(58, 23)
        Me.lblUserNum1.TabIndex = 7
        Me.lblUserNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(28, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 23)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Computer:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(28, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 23)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "User:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 200)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblUserNum5)
        Me.Controls.Add(Me.lblUserNum4)
        Me.Controls.Add(Me.lblUserNum3)
        Me.Controls.Add(Me.lblUserNum2)
        Me.Controls.Add(Me.lblUserNum1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnGenerate)
        Me.Controls.Add(Me.lblNum5)
        Me.Controls.Add(Me.lblNum4)
        Me.Controls.Add(Me.lblNum3)
        Me.Controls.Add(Me.lblNum2)
        Me.Controls.Add(Me.lblNum1)
        Me.Name = "Form1"
        Me.Text = "Lottery"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblNum1 As Label
    Friend WithEvents lblNum2 As Label
    Friend WithEvents lblNum3 As Label
    Friend WithEvents lblNum4 As Label
    Friend WithEvents lblNum5 As Label
    Friend WithEvents btnGenerate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblUserNum5 As System.Windows.Forms.Label
    Friend WithEvents lblUserNum4 As System.Windows.Forms.Label
    Friend WithEvents lblUserNum3 As System.Windows.Forms.Label
    Friend WithEvents lblUserNum2 As System.Windows.Forms.Label
    Friend WithEvents lblUserNum1 As System.Windows.Forms.Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
